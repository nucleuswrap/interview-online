// 1. Given an array of ints
// 2. Count the positive numbers
// 3. Sum the negative numbers
// 4. Return an int array size 2 with array[0] = count of positive numbers, array[1] = sum the negative numbers

export function countPositivesSumNegatives(arr) {
  return [0, 0];
}
