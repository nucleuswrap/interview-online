# Nucleus practical coding questions

**Sum**

Write an algorithm that sum the number given in an array

