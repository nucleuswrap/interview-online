package com.nucleusfinancial.interview.code;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class SumTest {

    @Test
    public void sum_array_item() {
        assertEquals(23L, Sum.sumElements(new int[] { 3, 1, 4, 1, 5, 9 }));
    }

    @Test
    public void sum_array_of_1() {
        assertEquals(1L, Sum.sumElements(new int[] { 1 }));
    }

    @Test
    public void sum_array_of_0() {
        assertEquals(0L, Sum.sumElements(new int[] { 0 }));
    }

    @Test
    public void sum_empty_array() {
        assertEquals(0L, Sum.sumElements(new int[] {}));
    }

    @Test
    public void sum_array_of_1s() {
        assertEquals(7L, Sum.sumElements(new int[] { 1, 1, 1, 1, 1, 1, 1 }));
    }

}
