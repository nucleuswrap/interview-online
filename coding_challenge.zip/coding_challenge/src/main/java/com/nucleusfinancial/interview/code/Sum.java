package com.nucleusfinancial.interview.code;

public class Sum {

    public static long sumElements(int[] numberArray) {
        //Your implementation goes here
        return 0;
    }

}
