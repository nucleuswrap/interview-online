// Write an algorithm that adds one to the input. The input is an array representing an integer (ex: [1,2,3] => 123).

// For instance:
// [1, 2, 3] => [1, 2, 4]
// [1,9] => [2, 0]

export function addOne(arr) {
  let result = [];

  return result;
}
