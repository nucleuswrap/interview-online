import { expect } from 'chai';
import * as one from '../src/Sum';

describe('SumTest', () => {

    it('sums list item', () => {
        expect(one.sumElements([3, 1, 4, 1, 5, 9])).to.equal(23);
    });

    it('sums list of 1', () => {
        expect(one.sumElements([1])).to.equal(1);
    });

    it('sums list of 0', () => {
        expect(one.sumElements([0])).to.equal(0);
    });

    it('sums empty list', () => {
        expect(one.sumElements([])).to.equal(0);
    });

    it('sums list of 1s', () => {
        expect(one.sumElements([1, 1, 1, 1, 1, 1, 1])).to.equal(7);
    });
})
