// 1. Given a string of words split by the space character
// 2. Return a map containing each distinct word and the number of occurrences
// E.G.
// "foo foo bar" will return a map of foo: 2, bar: 1

export function countDistinctWords(words) {
  return {};
}
