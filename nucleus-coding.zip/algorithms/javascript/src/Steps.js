// Write an algorithm that returns a string which represents a staircase such that "staircase(4)" will give the following result:
//
//    #
//   ##
//  ###
// ####
// N.B. the last line does not have any cr/lf or spaces.

export function staircase(n) {
  let output = "";
  return output;
}
