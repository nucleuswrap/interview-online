export function sumElements(listOfNumbers) {
    //Your implementations goes here
    return 0;
} 
