package com.nucleusfinancial.interview.code;

// 1. Given an array of ints
// 2. Count the positive numbers
// 3. Sum the negative numbers
// 4. Return an int array size 2 with array[0] = count of positive numbers, array[1] = sum the negative numbers

public class CountAndSum {
    public static int[] countPositivesSumNegatives(int[] arr) {
        return new int[] { 0, 0 };
    }
}
