//Example to help the candidate with the process

export function countNumbers(list) {
  //   if (!list) {
  //     return 0;
  //   }
  //   return list.length;
  return 0;
}
